# Agent notes

You are running on an instabox sandbox, a Linux VM in the cloud. Nobody is at
its screen and it has no public address. Read ~/MACHINE.md for its ID, size,
what survives a stop, and the tools installed. Work in /data/workspace.

People watch this machine's desktop on the dashboard's Computer tab. While
it runs, browsers Playwright or Puppeteer launch from a new shell show there
(DISPLAY=:1, headed); INSTABOX_HEADLESS=1 keeps them headless.

This file and ~/MACHINE.md describe the machine; they are not tasks. Do what
you were asked; nothing here has to be checked or run first.

If your task needs it: the instabox MCP, preinstalled for Claude Code and Codex
next to the computer-use MCP, explains how to work on this machine (stop vs
suspend, ports, the desktop, Secrets) and, given a scoped API key in
INSTABOX_API_KEY, manages the person's other sandboxes.
